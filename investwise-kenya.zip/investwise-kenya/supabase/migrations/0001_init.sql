-- InvestWise Kenya: core schema, RLS, atomic payment settlement.
create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text, full_name text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

-- Prevent customers from promoting themselves.
create or replace function public.guard_profile_role() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role and not (public.is_admin() or auth.role() = 'service_role') then
    raise exception 'role change not permitted';
  end if;
  return new;
end $$;
create trigger profiles_guard_role before update on public.profiles for each row execute function public.guard_profile_role();

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email) values (new.id, new.email);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Reports are products with kind = 'report'.
create table public.products (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  kind text not null check (kind in ('report','digital')),
  title text not null,
  summary text not null default '',
  description text not null default '',
  preview text not null default '',
  price_kes integer not null check (price_kes > 0 and price_kes <= 150000),
  published boolean not null default false,
  file_path text,                       -- path in the private 'products' bucket
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index products_published_idx on public.products (published, kind);

create table public.articles (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique, title text not null, excerpt text not null default '',
  body_md text not null default '', published boolean not null default false,
  views integer not null default 0,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  reference text not null unique,
  user_id uuid not null references auth.users(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict,
  amount_kes integer not null check (amount_kes > 0),   -- price snapshot taken on the server
  status text not null default 'pending' check (status in ('pending','paid','failed','cancelled')),
  created_at timestamptz not null default now()
);
create index orders_user_idx on public.orders (user_id, created_at desc);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete restrict,
  checkout_request_id text unique, merchant_request_id text,
  phone_last4 text, amount_kes integer not null,
  status text not null default 'pending' check (status in ('pending','successful','failed','cancelled')),
  mpesa_receipt text unique, result_code integer, result_desc text,
  raw_callback jsonb, settled_at timestamptz,
  created_at timestamptz not null default now()
);
create index payments_pending_idx on public.payments (status, created_at);

create table public.entitlements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  order_id uuid not null unique references public.orders(id) on delete restrict,
  created_at timestamptz not null default now(),
  unique (user_id, product_id)
);

create table public.downloads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table public.ai_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  day date not null default current_date, count integer not null default 0,
  primary key (user_id, day)
);
create table public.analytics_events (
  id bigserial primary key,
  event text not null check (event in ('page_view','product_view','checkout_started','purchase','article_view')),
  path text, product_id uuid, created_at timestamptz not null default now()   -- no user identifiers stored
);
create table public.audit_logs (
  id bigserial primary key, actor uuid, action text not null, target text, detail jsonb,
  created_at timestamptz not null default now()
);

-- Atomic, idempotent settlement. Only callable with the service role.
create or replace function public.settle_payment(
  p_checkout_request_id text, p_result_code integer, p_result_desc text,
  p_receipt text, p_amount integer, p_raw jsonb
) returns text language plpgsql security definer set search_path = public as $$
declare pay public.payments; ord public.orders; new_status text;
begin
  select * into pay from public.payments where checkout_request_id = p_checkout_request_id for update;
  if not found then return 'unknown_payment'; end if;
  if pay.status <> 'pending' then return 'already_' || pay.status; end if;   -- duplicate callback: no-op
  select * into ord from public.orders where id = pay.order_id for update;

  if p_result_code = 0 then
    if p_amount is distinct from pay.amount_kes or p_receipt is null then
      update public.payments set status='failed', result_code=p_result_code,
        result_desc='amount mismatch or missing receipt', raw_callback=p_raw, settled_at=now() where id = pay.id;
      update public.orders set status='failed' where id = ord.id;
      insert into public.audit_logs(action, target, detail) values ('payment_mismatch', pay.id::text, p_raw);
      return 'mismatch';
    end if;
    update public.payments set status='successful', result_code=0, result_desc=p_result_desc,
      mpesa_receipt=p_receipt, raw_callback=p_raw, settled_at=now() where id = pay.id;
    update public.orders set status='paid' where id = ord.id;
    insert into public.entitlements(user_id, product_id, order_id) values (ord.user_id, ord.product_id, ord.id)
      on conflict do nothing;
    insert into public.analytics_events(event, product_id) values ('purchase', ord.product_id);
    return 'successful';
  end if;

  new_status := case when p_result_code = 1032 then 'cancelled' else 'failed' end;
  update public.payments set status=new_status, result_code=p_result_code, result_desc=p_result_desc,
    raw_callback=p_raw, settled_at=now() where id = pay.id;
  update public.orders set status = new_status where id = ord.id;
  return new_status;
end $$;
revoke all on function public.settle_payment(text,integer,text,text,integer,jsonb) from public, anon, authenticated;
grant execute on function public.settle_payment(text,integer,text,text,integer,jsonb) to service_role;

-- RLS
alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.articles enable row level security;
alter table public.orders enable row level security;
alter table public.payments enable row level security;
alter table public.entitlements enable row level security;
alter table public.downloads enable row level security;
alter table public.ai_usage enable row level security;
alter table public.analytics_events enable row level security;
alter table public.audit_logs enable row level security;

create policy profiles_self_read on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy profiles_self_update on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

create policy products_public_read on public.products for select using (published or public.is_admin());
create policy products_admin_write on public.products for all using (public.is_admin()) with check (public.is_admin());
create policy articles_public_read on public.articles for select using (published or public.is_admin());
create policy articles_admin_write on public.articles for all using (public.is_admin()) with check (public.is_admin());

-- Orders/entitlements/downloads: owners read; writes happen only via the service role.
create policy orders_owner_read on public.orders for select using (user_id = auth.uid() or public.is_admin());
create policy entitlements_owner_read on public.entitlements for select using (user_id = auth.uid() or public.is_admin());
create policy downloads_owner_read on public.downloads for select using (user_id = auth.uid() or public.is_admin());
-- Payments contain receipts and raw callbacks: admin read only.
create policy payments_admin_read on public.payments for select using (public.is_admin());
create policy ai_usage_owner_read on public.ai_usage for select using (user_id = auth.uid());
create policy analytics_admin_read on public.analytics_events for select using (public.is_admin());
create policy audit_admin_read on public.audit_logs for select using (public.is_admin());

-- Private bucket: no storage policies for anon/authenticated, so files are reachable only via server-issued signed URLs.
insert into storage.buckets (id, name, public) values ('products', 'products', false) on conflict (id) do nothing;

-- Seed defaults (unpublished until an admin reviews them).
insert into public.products (slug, kind, title, summary, price_kes, published) values
 ('sample-report', 'report', 'Sample financial report', 'Placeholder: replace with real content.', 150, false),
 ('sample-guide',  'digital','Sample digital guide',    'Placeholder: replace with real content.', 100, false);

import { z } from 'zod';
import { timingSafeEqual } from 'node:crypto';

const item = z.object({ Name: z.string(), Value: z.union([z.string(), z.number()]).optional() });
export const callbackSchema = z.object({
  Body: z.object({ stkCallback: z.object({
    MerchantRequestID: z.string(), CheckoutRequestID: z.string(),
    ResultCode: z.number().int(), ResultDesc: z.string(),
    CallbackMetadata: z.object({ Item: z.array(item) }).optional(),
  }) }),
});

export interface ParsedCallback {
  checkoutRequestId: string; resultCode: number; resultDesc: string; receipt: string | null; amount: number | null;
}
export function parseCallback(body: unknown): ParsedCallback | null {
  const r = callbackSchema.safeParse(body);
  if (!r.success) return null;
  const cb = r.data.Body.stkCallback;
  const get = (n: string) => cb.CallbackMetadata?.Item.find(i => i.Name === n)?.Value;
  const amt = get('Amount'), rcpt = get('MpesaReceiptNumber');
  return {
    checkoutRequestId: cb.CheckoutRequestID, resultCode: cb.ResultCode, resultDesc: cb.ResultDesc,
    receipt: typeof rcpt === 'string' ? rcpt : null, amount: amt === undefined ? null : Number(amt),
  };
}

/** Constant-time compare for URL-path secrets / bearer secrets. */
export function secretsMatch(a: string, b: string): boolean {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

export const checkoutSchema = z.object({
  productId: z.string().uuid(),
  phone: z.string().min(9).max(16),   // price is deliberately NOT accepted from the client
});

export const formatKES = (n: number): string =>
  new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES', maximumFractionDigits: 0 }).format(n);

/** Normalises 07xx, 01xx, 7xx, +254… and 254… to 254XXXXXXXXX; returns null if invalid. */
export function normalizeKenyanPhone(input: string): string | null {
  const d = input.replace(/[\s\-()]/g, '').replace(/^\+/, '');
  let n: string;
  if (/^0[17]\d{8}$/.test(d)) n = '254' + d.slice(1);
  else if (/^[17]\d{8}$/.test(d)) n = '254' + d;
  else if (/^254[17]\d{8}$/.test(d)) n = d;
  else return null;
  return n;
}

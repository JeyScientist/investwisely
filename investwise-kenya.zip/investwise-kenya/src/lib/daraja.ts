import 'server-only';
import { serverEnv } from './env';

const base = (env: string) => (env === 'production' ? 'https://api.safaricom.co.ke' : 'https://sandbox.safaricom.co.ke');

export function stkTimestamp(d = new Date()): string {
  const p = (n: number) => String(n).padStart(2, '0');
  // Daraja expects East Africa Time (UTC+3)
  const e = new Date(d.getTime() + 3 * 3600_000);
  return `${e.getUTCFullYear()}${p(e.getUTCMonth() + 1)}${p(e.getUTCDate())}${p(e.getUTCHours())}${p(e.getUTCMinutes())}${p(e.getUTCSeconds())}`;
}
export const stkPassword = (shortcode: string, passkey: string, ts: string) =>
  Buffer.from(shortcode + passkey + ts).toString('base64');

async function accessToken(): Promise<string> {
  const e = serverEnv();
  const auth = Buffer.from(`${e.DARAJA_CONSUMER_KEY}:${e.DARAJA_CONSUMER_SECRET}`).toString('base64');
  const res = await fetch(`${base(e.DARAJA_ENVIRONMENT)}/oauth/v1/generate?grant_type=client_credentials`,
    { headers: { Authorization: `Basic ${auth}` }, cache: 'no-store' });
  if (!res.ok) throw new Error(`Daraja auth failed (${res.status})`);
  return ((await res.json()) as { access_token: string }).access_token;
}

export async function stkPush(a: { phone: string; amount: number; reference: string; description: string }) {
  const e = serverEnv(); const ts = stkTimestamp();
  const res = await fetch(`${base(e.DARAJA_ENVIRONMENT)}/mpesa/stkpush/v1/processrequest`, {
    method: 'POST', cache: 'no-store',
    headers: { Authorization: `Bearer ${await accessToken()}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      BusinessShortCode: e.DARAJA_SHORTCODE, Password: stkPassword(e.DARAJA_SHORTCODE, e.DARAJA_PASSKEY, ts),
      Timestamp: ts, TransactionType: 'CustomerPayBillOnline', Amount: a.amount, PartyA: a.phone,
      PartyB: e.DARAJA_SHORTCODE, PhoneNumber: a.phone,
      CallBackURL: `${e.DARAJA_CALLBACK_URL.replace(/\/$/, '')}/${e.MPESA_CALLBACK_SECRET}`,
      AccountReference: a.reference.slice(0, 12), TransactionDesc: a.description.slice(0, 13),
    }),
  });
  const j = (await res.json()) as { ResponseCode?: string; CheckoutRequestID?: string; MerchantRequestID?: string; errorMessage?: string };
  if (!res.ok || j.ResponseCode !== '0' || !j.CheckoutRequestID) throw new Error(`STK push rejected: ${j.errorMessage ?? res.status}`);
  return { checkoutRequestId: j.CheckoutRequestID, merchantRequestId: j.MerchantRequestID ?? null };
}

/** Asks Safaricom directly for the result. Used by reconciliation so we never rely on callbacks alone. */
export async function stkQuery(checkoutRequestId: string) {
  const e = serverEnv(); const ts = stkTimestamp();
  const res = await fetch(`${base(e.DARAJA_ENVIRONMENT)}/mpesa/stkpushquery/v1/query`, {
    method: 'POST', cache: 'no-store',
    headers: { Authorization: `Bearer ${await accessToken()}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ BusinessShortCode: e.DARAJA_SHORTCODE, Password: stkPassword(e.DARAJA_SHORTCODE, e.DARAJA_PASSKEY, ts), Timestamp: ts, CheckoutRequestID: checkoutRequestId }),
  });
  const j = (await res.json()) as { ResultCode?: string | number; ResultDesc?: string; errorCode?: string };
  if (j.ResultCode === undefined) return null; // still processing / not found: try again later
  return { resultCode: Number(j.ResultCode), resultDesc: j.ResultDesc ?? '' };
}

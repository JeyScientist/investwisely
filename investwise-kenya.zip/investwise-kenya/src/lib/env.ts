import { z } from 'zod';
const schema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
  AI_API_KEY: z.string().min(1),
  AI_MODEL: z.string().min(1),
  DARAJA_ENVIRONMENT: z.enum(['sandbox', 'production']),
  DARAJA_CONSUMER_KEY: z.string().min(1),
  DARAJA_CONSUMER_SECRET: z.string().min(1),
  DARAJA_SHORTCODE: z.string().min(1),
  DARAJA_PASSKEY: z.string().min(1),
  DARAJA_CALLBACK_URL: z.string().url(),
  MPESA_CALLBACK_SECRET: z.string().min(24),
  CRON_SECRET: z.string().min(24),
});
export type ServerEnv = z.infer<typeof schema>;
/** Server-only. Throws a clear error naming missing variables (never their values). */
export function serverEnv(): ServerEnv {
  const r = schema.safeParse(process.env);
  if (!r.success) throw new Error('Missing/invalid env: ' + r.error.issues.map(i => i.path.join('.')).join(', '));
  return r.data;
}

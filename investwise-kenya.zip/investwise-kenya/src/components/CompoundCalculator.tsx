'use client';
import { useMemo, useState } from 'react';
import { projectGrowth } from '@/lib/calculators';
import { formatKES } from '@/lib/money';

const fields = [
  ['principal', 'Starting amount (KSh)', 0], ['monthlyContribution', 'Monthly contribution (KSh)', 0],
  ['annualRatePct', 'Assumed annual return (%)', 0], ['years', 'Years (1-60)', 1], ['annualInflationPct', 'Assumed inflation (% a year)', 0],
] as const;

export function CompoundCalculator() {
  const [v, setV] = useState({ principal: 50000, monthlyContribution: 5000, annualRatePct: 8, years: 10, annualInflationPct: 5 });
  const { rows, error } = useMemo(() => {
    try { return { rows: projectGrowth(v), error: null }; } catch (e) { return { rows: [], error: (e as Error).message }; }
  }, [v]);
  const end = rows.at(-1);
  return (
    <div className="mt-8 grid gap-8 md:grid-cols-[320px_1fr]">
      <form className="space-y-4" onSubmit={e => e.preventDefault()} aria-label="Assumptions">
        {fields.map(([k, label, min]) => (
          <div key={k}><label htmlFor={k} className="block text-sm text-slate-300">{label}</label>
            <input id={k} type="number" inputMode="decimal" min={min} step="any" value={Number.isFinite(v[k]) ? v[k] : ''}
              onChange={e => setV({ ...v, [k]: Math.max(min, Number(e.target.value)) })}
              className="mt-1 w-full rounded border border-navy-700 bg-navy-900 px-3 py-2" /></div>))}
      </form>
      <section aria-live="polite">
        {error ? <p role="alert" className="text-red-400">Check your inputs: {error}.</p> : !end ? null : (<>
          <dl className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-lg bg-navy-900 p-4"><dt className="text-sm text-slate-400">Estimated balance</dt><dd className="text-xl font-semibold text-emerald">{formatKES(Math.round(end.balance))}</dd></div>
            <div className="rounded-lg bg-navy-900 p-4"><dt className="text-sm text-slate-400">You contributed</dt><dd className="text-xl font-semibold">{formatKES(Math.round(end.contributed))}</dd></div>
            <div className="rounded-lg bg-navy-900 p-4"><dt className="text-sm text-slate-400">In today&apos;s money</dt><dd className="text-xl font-semibold text-gold">{formatKES(Math.round(end.realBalance))}</dd></div>
          </dl>
          <div className="mt-6 overflow-x-auto"><table className="w-full text-left text-sm">
            <caption className="sr-only">Year-by-year projection</caption>
            <thead className="text-slate-400"><tr><th className="py-2">Year</th><th>Balance</th><th>Contributed</th><th>Real value</th></tr></thead>
            <tbody>{rows.map(r => <tr key={r.year} className="border-t border-navy-800"><td className="py-1.5">{r.year}</td><td>{formatKES(Math.round(r.balance))}</td><td>{formatKES(Math.round(r.contributed))}</td><td>{formatKES(Math.round(r.realBalance))}</td></tr>)}</tbody>
          </table></div>
          <p className="mt-4 text-xs text-slate-500">Estimate only. Returns are not guaranteed and investments can lose value. Check current rates and fees with the provider.</p></>)}
      </section>
    </div>
  );
}

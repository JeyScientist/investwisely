import type { Metadata } from 'next';
import Link from 'next/link';
import './globals.css';

const site = process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000';
export const metadata: Metadata = {
  metadataBase: new URL(site),
  title: { default: 'InvestWise Kenya: financial education', template: '%s | InvestWise Kenya' },
  description: 'Calculators, guides and reports that explain saving, investing and risk in plain language for Kenya.',
  openGraph: { title: 'InvestWise Kenya', description: 'Financial education for Kenya.', type: 'website' },
};

const nav: [string, string][] = [['Learn', '/learn'], ['Tools', '/tools'], ['Reports', '/reports'], ['Products', '/products'], ['AI guide', '/ai-guide'], ['Pricing', '/pricing']];

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="border-b border-navy-700">
          <nav aria-label="Main" className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-4">
            <Link href="/" className="mr-auto text-lg font-semibold">InvestWise <span className="text-gold">Kenya</span></Link>
            {nav.map(([l, h]) => <Link key={h} href={h} className="text-sm text-slate-300 hover:text-white">{l}</Link>)}
            <Link href="/login" className="rounded bg-emerald px-3 py-1.5 text-sm font-medium text-navy-950 hover:bg-emerald-400">Sign in</Link>
          </nav>
        </header>
        <main className="mx-auto max-w-6xl px-4 py-10">{children}</main>
        <footer className="border-t border-navy-700 px-4 py-8 text-sm text-slate-400">
          <div className="mx-auto max-w-6xl">
            <p>InvestWise Kenya provides general financial education, not personalised financial advice. Investments carry risk, including loss of capital.</p>
            <p className="mt-2 flex gap-4"><Link href="/disclaimer">Disclaimer</Link><Link href="/privacy">Privacy</Link><Link href="/terms">Terms</Link><Link href="/contact">Contact</Link></p>
          </div>
        </footer>
      </body>
    </html>
  );
}

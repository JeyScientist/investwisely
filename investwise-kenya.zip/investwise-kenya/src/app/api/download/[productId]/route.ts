import { NextResponse } from 'next/server';
import { getUser } from '@/lib/auth';
import { adminClient } from '@/lib/supabase/admin';

export async function GET(_: Request, ctx: { params: Promise<{ productId: string }> }) {
  const { productId } = await ctx.params;
  const user = await getUser();
  if (!user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 });
  const db = adminClient();
  const { data: ent } = await db.from('entitlements').select('id').eq('user_id', user.id).eq('product_id', productId).maybeSingle();
  if (!ent) return NextResponse.json({ error: 'No purchase found for this item.' }, { status: 403 });
  const { data: product } = await db.from('products').select('file_path').eq('id', productId).single();
  if (!product?.file_path) return NextResponse.json({ error: 'File not available yet.' }, { status: 404 });
  const { data: signed } = await db.storage.from('products').createSignedUrl(product.file_path, 60);
  if (!signed) return NextResponse.json({ error: 'Could not prepare download.' }, { status: 500 });
  await db.from('downloads').insert({ user_id: user.id, product_id: productId });
  return NextResponse.redirect(signed.signedUrl, 302);
}

import { NextResponse } from 'next/server';
import { randomBytes } from 'node:crypto';
import { checkoutSchema } from '@/lib/payments';
import { normalizeKenyanPhone } from '@/lib/money';
import { getUser } from '@/lib/auth';
import { adminClient } from '@/lib/supabase/admin';
import { stkPush } from '@/lib/daraja';
import { rateLimit } from '@/lib/ratelimit';

export async function POST(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: 'Sign in to continue.' }, { status: 401 });
  if (!rateLimit(`checkout:${user.id}`, 5, 60_000)) return NextResponse.json({ error: 'Too many attempts. Wait a minute.' }, { status: 429 });

  const parsed = checkoutSchema.safeParse(await req.json().catch(() => null));
  const phone = parsed.success ? normalizeKenyanPhone(parsed.data.phone) : null;
  if (!parsed.success || !phone) return NextResponse.json({ error: 'Enter a valid Safaricom number, e.g. 0712345678.' }, { status: 400 });

  const db = adminClient();
  // Price comes from the database, never from the request.
  const { data: product } = await db.from('products').select('id,title,price_kes,published').eq('id', parsed.data.productId).single();
  if (!product || !product.published) return NextResponse.json({ error: 'Product not available.' }, { status: 404 });

  const { data: owned } = await db.from('entitlements').select('id').eq('user_id', user.id).eq('product_id', product.id).maybeSingle();
  if (owned) return NextResponse.json({ error: 'You already own this item.' }, { status: 409 });

  const reference = 'IW' + randomBytes(5).toString('hex').toUpperCase();
  const { data: order, error: oErr } = await db.from('orders')
    .insert({ reference, user_id: user.id, product_id: product.id, amount_kes: product.price_kes }).select('id').single();
  if (oErr || !order) return NextResponse.json({ error: 'Could not create order.' }, { status: 500 });

  try {
    const stk = await stkPush({ phone, amount: product.price_kes, reference, description: 'InvestWise' });
    await db.from('payments').insert({
      order_id: order.id, checkout_request_id: stk.checkoutRequestId, merchant_request_id: stk.merchantRequestId,
      phone_last4: phone.slice(-4), amount_kes: product.price_kes,
    });
    await db.from('analytics_events').insert({ event: 'checkout_started', product_id: product.id });
    return NextResponse.json({ orderId: order.id, reference, status: 'pending', message: 'Check your phone and enter your M-Pesa PIN.' });
  } catch {
    await db.from('orders').update({ status: 'failed' }).eq('id', order.id);
    return NextResponse.json({ error: 'Payment request failed. Try again shortly.' }, { status: 502 });
  }
}

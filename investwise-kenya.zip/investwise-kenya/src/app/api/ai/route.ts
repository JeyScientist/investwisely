import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getUser } from '@/lib/auth';
import { rateLimit } from '@/lib/ratelimit';
import { serverEnv } from '@/lib/env';

const body = z.object({ messages: z.array(z.object({ role: z.enum(['user', 'assistant']), content: z.string().min(1).max(2000) })).min(1).max(12) });

const SYSTEM = `You are the InvestWise Kenya education assistant. You explain financial terms and concepts (risk, diversification, inflation, compound growth, how common asset types work) in simple language, with Kenyan context where you are confident of it.
Rules: You give general education only, never personalised advice or recommendations to buy, sell or hold a specific product. You do not state live prices, current interest rates, guaranteed returns or current regulations; when a question depends on these, say it changes and the user must verify with the issuing institution, the Capital Markets Authority (CMA), the Central Bank of Kenya, or the Kenya Revenue Authority. If unsure, say so. For personal decisions, suggest a licensed financial adviser.`;

export async function POST(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: 'Sign in to use the assistant.' }, { status: 401 });
  if (!rateLimit(`ai:${user.id}`, 10, 60_000)) return NextResponse.json({ error: 'Slow down: try again in a minute.' }, { status: 429 });
  const parsed = body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: 'Invalid request.' }, { status: 400 });

  const env = serverEnv();
  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': env.AI_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: env.AI_MODEL, max_tokens: 700, system: SYSTEM, messages: parsed.data.messages }),
    });
    if (!res.ok) return NextResponse.json({ error: 'The assistant is unavailable right now.' }, { status: 502 });
    const j = (await res.json()) as { content: { type: string; text?: string }[] };
    const reply = j.content.filter(b => b.type === 'text').map(b => b.text).join('\n');
    return NextResponse.json({ reply, notice: 'Educational information only, not financial advice.' });
  } catch {
    return NextResponse.json({ error: 'The assistant is unavailable right now.' }, { status: 502 });
  }
}

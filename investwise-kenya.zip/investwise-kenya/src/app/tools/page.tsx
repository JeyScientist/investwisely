import Link from 'next/link';
export const metadata = { title: 'Financial calculators' };
const tools: [string, string, string][] = [['/tools/compound-interest', 'Compound interest', 'See growth with monthly contributions and inflation.']];
export default function Tools() {
  return (<div><h1 className="text-3xl font-semibold">Calculators</h1>
    <p className="mt-2 text-slate-300">All results are estimates based on the assumptions you enter.</p>
    <ul className="mt-6 grid gap-4 md:grid-cols-2">{tools.map(([h, t, d]) => (
      <li key={h}><Link href={h} className="block rounded-lg border border-navy-700 bg-navy-900 p-5 hover:border-emerald"><span className="font-medium">{t}</span><span className="mt-1 block text-sm text-slate-400">{d}</span></Link></li>))}</ul></div>);
}

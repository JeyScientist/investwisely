import { describe, it, expect } from 'vitest';
import { projectGrowth, monthlySavingsNeeded, realValue } from '@/lib/calculators';

const base = { principal: 100000, monthlyContribution: 0, annualRatePct: 10, years: 10, annualInflationPct: 0 };

describe('projectGrowth', () => {
  it('matches the closed-form for annual compounding with no contributions', () => {
    const end = projectGrowth({ ...base, compoundsPerYear: 1 }).at(-1)!;
    expect(end.balance).toBeCloseTo(100000 * 1.1 ** 10, 0);
  });
  it('tracks contributions and nominal vs real values', () => {
    const end = projectGrowth({ ...base, monthlyContribution: 5000, annualRatePct: 0, annualInflationPct: 5, years: 2 }).at(-1)!;
    expect(end.balance).toBe(100000 + 5000 * 24);
    expect(end.contributed).toBe(220000);
    expect(end.realBalance).toBeCloseTo(220000 / 1.05 ** 2, 2);
  });
  it('rejects unsupported inputs', () => {
    expect(() => projectGrowth({ ...base, years: 100 })).toThrow(RangeError);
    expect(() => projectGrowth({ ...base, compoundsPerYear: 7 })).toThrow(RangeError);
  });
});

describe('monthlySavingsNeeded', () => {
  it('is target/months at 0% return', () => {
    expect(monthlySavingsNeeded(120000, 0, 0, 1)).toBeCloseTo(10000, 6);
  });
  it('reaches the target when used in the projection', () => {
    const m = monthlySavingsNeeded(1_000_000, 50_000, 8, 5);
    const end = projectGrowth({ principal: 50_000, monthlyContribution: m, annualRatePct: 8, years: 5, annualInflationPct: 0 }).at(-1)!;
    expect(end.balance).toBeCloseTo(1_000_000, 0);
  });
  it('needs nothing when current savings already grow past the target', () => {
    expect(monthlySavingsNeeded(100, 1_000_000, 5, 2)).toBe(0);
  });
});

describe('realValue', () => { it('discounts by inflation', () => expect(realValue(1050, 5, 1)).toBeCloseTo(1000, 6)); });

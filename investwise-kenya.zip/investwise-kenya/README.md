# InvestWise Kenya

Financial education and paid digital products for Kenya. Next.js 15 (App Router), TypeScript, Tailwind, Supabase, Daraja M-Pesa STK Push.

## Status (honest)
**Built and verified here:** project config and security headers; Supabase migration (tables, RLS, private bucket, atomic idempotent `settle_payment`); calculators with tests; M-Pesa checkout, callback, reconcile and signed-download routes; AI assistant route; landing page, calculators index, compound interest calculator; sitemap/robots. `tsc`, `next build` and `vitest` (22 tests) pass.

**Not built yet:** pages for `/about /learn /budget /savings /investment /reports /products /products/[slug] /ai-guide (UI) /pricing /login /signup /dashboard* /admin* /privacy /terms /disclaimer /contact`; Supabase auth UI and middleware; admin CRUD; analytics page-view tracking and dashboards; charts; component tests for authorization.
**Never run against live services:** Supabase, Daraja and the AI API (no credentials were available). The SQL migration has not been executed against a database.

## Setup
1. `npm install`, then `cp .env.example .env.local` and fill the values.
2. Supabase: create a project, then run `supabase/migrations/0001_init.sql` in the SQL editor (or `supabase db push`). Copy URL, anon key and service-role key into `.env.local`. The service-role key is server-only.
3. First admin: sign up normally, then in the SQL editor run `update public.profiles set role='admin' where email='you@example.com';`. A trigger blocks customers from changing their own role.
4. `npm run dev`, `npm test`, `npm run lint` (type-check), `npm run build`.

## M-Pesa (Daraja)
1. Create an app at developer.safaricom.co.ke; use the sandbox shortcode and passkey first.
2. Set `DARAJA_ENVIRONMENT=sandbox`, key, secret, shortcode, passkey.
3. `DARAJA_CALLBACK_URL` must be public HTTPS ending in `/api/mpesa/callback` (use your Vercel URL or a tunnel). The server appends `MPESA_CALLBACK_SECRET` as the final path segment; requests without it get 404.
4. Going live: apply for Go-Live on the Daraja portal, get your production shortcode and passkey, set `DARAJA_ENVIRONMENT=production`.
5. Reconciliation: schedule `GET /api/mpesa/reconcile` with header `Authorization: Bearer $CRON_SECRET` (e.g. Vercel Cron, every 5 minutes). It settles failed/cancelled payments. A Daraja query success has no receipt, so it is logged to `audit_logs` for admin review rather than granting access automatically.

## Security model
- Prices are read from the database at checkout; the request body cannot carry a price.
- Access is granted only by `settle_payment` (service role) when the callback reports success, the amount matches, and a receipt is present. Duplicate callbacks are no-ops (row lock + status check).
- Customers read only their own orders, entitlements and downloads; payments and audit logs are admin-only; files are served via 60-second signed URLs after an entitlement check.
- Secrets live only in server environment variables.

## Deploy (Vercel)
Push to GitHub, import into Vercel, add every variable from `.env.example`, deploy. Troubleshooting: "Missing/invalid env" errors name the missing variable; callback 404 means the secret in the URL does not match `MPESA_CALLBACK_SECRET`.

Rate limiting is in-memory per instance; use a shared store (e.g. Upstash Redis) for production.
Educational content only: this is not personalised financial advice.
